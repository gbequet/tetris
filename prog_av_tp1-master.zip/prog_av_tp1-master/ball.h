#ifndef _BALL_H_
#define _BALL_H_

class Ball
{

} ;

#endif
