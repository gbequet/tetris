#ifndef _SURFACE_H_
#define _SURFACE_H_

#include <SDL.h>
#include <string>

class Sprite;

class Surface
{

public: 
    Surface();
};

#endif