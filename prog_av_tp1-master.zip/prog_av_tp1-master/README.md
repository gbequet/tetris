# TP1 encapsulation SDL, Classes & std #

Le but du TP est de transformer le programme fourni tp1_base.cpp
en une version propre utilisant le maximum de fonctionnalité du C++
* classes
* héritage
* liste d'initialisation
* const
* références
* std::vector
* lambda
* ....

Les classes et fichiers sont déja créé (une proposition)
**Attention** la cible TP\_CPP\_SDL ne compile pas (vous devez compléter les sources).
La cible TP\_SDL compile.

Vous trouverez facilement la documentation de la lib SDL2 sur internet

La compilation utilise _CMake_ et fonctionne sous Linux, Windows, Mac

Les paquets nécessaire s'installent facilement sous windows avec _vcpkg_ et
sous MacOS avec _HomeBrew_.


Ce canevas vous servira de base pour la réalisation du projet **Tetris**

