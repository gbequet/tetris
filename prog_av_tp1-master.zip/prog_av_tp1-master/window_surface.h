#ifndef _WINDOW_SURFACE_
#define _WINDOW_SURFACE_


#include <SDL.h>
#include "surface.h"

class Sprite;

class WindowSurface : public Surface
{

};

#endif